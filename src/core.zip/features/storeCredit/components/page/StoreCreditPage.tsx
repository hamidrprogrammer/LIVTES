// File: ge/new project/app/profile/store-credit/page.tsx

import { StoreCreditListPage } from '@/features/storeCredit/components/StoreCreditListPage';


export default function UserStoreCreditPage() {
  
  return (
    <div>
   
      <StoreCreditListPage />
    
    </div>
  );
}