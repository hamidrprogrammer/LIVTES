import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { applyStoreMiddlewares } from '../../../core/middleware/zustandMiddleware';
import { login as loginService } from '../services/authApi';
import type { LoginPayload, LoginResponse, UserProfile } from '../../../core/types/api/auth';
import { ApiError } from '../../../core/api/apiUtils'; // Use the centralized ApiError
import { decodeJwt, isTokenValid } from '../../../core/utils/authUtils'; // Centralize JWT utilities

interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  user: UserProfile | null;
  isLoading: boolean; // Keep for local login process loading
  error: ApiError | null;
}

interface AuthActions {
  login: (payload: LoginPayload) => Promise<boolean>;
  logout: () => void;
  setTokens: (tokens: { accessToken: string; refreshToken?: string }) => void;
  clearAuthError: () => void;
}

const initialState: AuthState = {
  accessToken: null,
  refreshToken: null,
  isAuthenticated: false,
  user: null,
  isLoading: false,
  error: null,
};

export const useAuthStore = create<AuthState & AuthActions>()(
  applyStoreMiddlewares(
    persist(
      (set, get) => ({
        ...initialState,

        login: async (payload) => {
          set({ isLoading: true, error: null });
          try {
            // Pass showLoading: false to loginService as we manage loading state locally in the store
            const response: LoginResponse = await loginService(payload, false); 
            const { data } = response;

            set({
              accessToken: data.token,
              refreshToken: data.token || null, // Assuming refresh token is also returned as 'token' or handled separately
              isAuthenticated: true,
              user: data.user,
              isLoading: false,
              error: null,
            });

            if (typeof window !== 'undefined') {
              localStorage.setItem('authToken', data.token);
              // If a separate refreshToken is provided, store it
              // if (data.refreshToken) localStorage.setItem('refreshToken', data.refreshToken);
            }
            return true;
          } catch (error) {
            const apiError = error as ApiError;
            set({
              isLoading: false,
              error: apiError,
              isAuthenticated: false,
              user: null,
              accessToken: null,
              refreshToken: null,
            });
            console.error('Login failed:', apiError);
            return false;
          }
        },

        logout: () => {
          set({ ...initialState });
          if (typeof window !== 'undefined') {
            localStorage.removeItem('authToken');
            localStorage.removeItem('refreshToken');
          }
          // Dispatch global logout event
          if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('auth:logout', { detail: { reason: 'User initiated logout' } }));
          }
        },

        setTokens: ({ accessToken, refreshToken: newRefreshToken }) => {
          const isAuth = isTokenValid(accessToken);

          set(state => {
            state.accessToken = accessToken;
            if (newRefreshToken !== undefined) {
              state.refreshToken = newRefreshToken;
            }
            state.isAuthenticated = isAuth;
            if (!isAuth) {
              state.user = null;
              console.warn('Setting new token, but it appears to be expired or invalid.');
            }
          });
          if (typeof window !== 'undefined') {
            localStorage.setItem('authToken', accessToken);
            if (newRefreshToken) localStorage.setItem('refreshToken', newRefreshToken);
            else if (newRefreshToken === null) localStorage.removeItem('refreshToken');
          }
        },

        clearAuthError: () => {
          set({ error: null });
        },
      }),
      {
        name: 'auth-storage',
        storage: createJSONStorage(() => localStorage),
        partialize: (state) => ({
          accessToken: state.accessToken,
          refreshToken: state.refreshToken,
          isAuthenticated: state.isAuthenticated,
          user: state.user,
        }),
        onRehydrateStorage: (state) => {
          return (currentState, error) => {
            if (error) {
              console.error("AuthStore: An error occurred during rehydration:", error);
            } else if (currentState) {
              const token = currentState.accessToken;
              if (token && !isTokenValid(token)) {
                console.warn("AuthStore: Rehydrated token is expired or invalid. Clearing auth state.");
                currentState.isAuthenticated = false;
                currentState.accessToken = null;
                currentState.refreshToken = null;
                currentState.user = null;
              }
            }
          };
        },
      }
    ),
    'AuthStore'
  )
);

// selectors
export const selectIsAuthenticated = (state: AuthState) => state.isAuthenticated;
export const selectCurrentUser = (state: AuthState) => state.user;
export const selectAccessToken = (state: AuthState) => state.accessToken;
export const selectAuthIsLoading = (state: AuthState) => state.isLoading;
export const selectAuthError = (state: AuthState) => state.error;


